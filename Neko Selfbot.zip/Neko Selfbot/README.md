# kitsuneselfbot
people are calling my skids from this, its hella annoying, just enjoy the src code from me instead of some 'cracker'
